const accordion = document.getElementsByClassName('contentBx');

for (i = 0; i < accordion.length; i++) {
    accordion[i].addEventListener('click', function () {
        this.classList.toggle('active')
    })
};

const wrapper = document.querySelector(".wrapper"),
selectBtn = wrapper.querySelector(".select-btn"),
searchInp = wrapper.querySelector("input"),
options = wrapper.querySelector(".options");

let categories = ["Accounts", "Membership", "Posts", "Others"];

function addCategory(selectedCategory) {
    options.innerHTML = "";
    categories.forEach(category => {
        let isSelected = category == selectedCategory ? "selected" : "";
        let li = `<li onclick="updateName(this)" class="${isSelected}">${category}</li>`;
        options.insertAdjacentHTML("beforeend", li);
    });
}
addCategory();

function updateName(selectedLi) {
    searchInp.value = "";
    addCategory(selectedLi.innerText);
    wrapper.classList.remove("active");
    selectBtn.firstElementChild.innerText = selectedLi.innerText;
}

searchInp.addEventListener("keyup", () => {
    let arr = [];
    let searchWord = searchInp.value.toLowerCase();
    arr = categories.filter(data => {
        return data.toLowerCase().startsWith(searchWord);
    }).map(data => {
        let isSelected = data == selectBtn.firstElementChild.innerText ? "selected" : "";
        return `<li onclick="updateName(this)" class="${isSelected}">${data}</li>`;
    })
});

selectBtn.addEventListener("click", () => wrapper.classList.toggle("active"));